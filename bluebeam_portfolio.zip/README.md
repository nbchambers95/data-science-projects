# Analytics & Data Science Portfolio (Anonymized)

This repository contains anonymized, reproducible examples of my analytics work using synthetic or public-style data.
It highlights **forecasting**, **classification (churn)**, and **NLP sentiment** workflows end-to-end.

## Projects
1. **01_time_series_forecasting/**
   - Goal: Forecast daily sales with trends, weekly seasonality, holidays, and weather features.
   - Methods: EDA, feature engineering, ETS/ARIMA baseline, Random Forest Regressor, evaluation (MAE/MAPE).
2. **02_customer_churn_model/**
   - Goal: Predict churn from customer lifecycle and product usage signals.
   - Methods: Train/valid split, class balance checks, logistic regression & random forest, SHAP-style permutation importance.
3. **03_sentiment_analysis/**
   - Goal: Classify review sentiment and surface key terms.
   - Methods: Text cleaning, TF–IDF + Logistic Regression, evaluation (accuracy/F1), top n-grams.

> ⚠️ All datasets here are **synthetic** and do not reflect any real company or protected information.

## How to run
- Python 3.10+ recommended.
- `pip install -r requirements.txt`
- Run notebooks (or `.py`) in each project folder.

## Contact
Nathan Chambers, M.S. · Johnson City, TN · nbchambers95@gmail.com
